package backend;

public class TrainerDatabase extends Databases{
    
    public TrainerDatabase() {
        super("Trainers.txt");
    }

    @Override
    public Records createRecordFrom(String line) {
        String[] split = line.split(",\\s*");
        return new Trainer(split[0], split[1], split[2], split[3], split[4]);
    }

    
}
