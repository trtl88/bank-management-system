package backend;

public class ClassDatabase extends Databases {

    public ClassDatabase() {
        super("Class.txt");
    }

    @Override
    public Class createRecordFrom(String line) {
        String[] split = line.split(",\\s*");
        return new Class(split[0], split[1], split[2], Integer.parseInt(split[3]), Integer.parseInt(split[4]));
    }
}
