package backend;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class main {

    /*public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AdminRole admin = new AdminRole();
        TrainerRole trainer = new TrainerRole();

        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. Admin: Add Trainer");
            System.out.println("2. Admin: Delete Trainer");
            System.out.println("3. Trainer: Add Member");
            System.out.println("4. Trainer: Add Class");
            System.out.println("5. Trainer: Register Member for Class");
            System.out.println("6. Trainer: Cancel Registration");
            System.out.println("7. List Trainers");
            System.out.println("8. List Members");
            System.out.println("9. List Classes");
            System.out.println("10. List Registrations");
            System.out.println("11. Logout");
            System.out.println("0. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter Trainer ID: ");
                    String trainerId = scanner.nextLine();
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter Specialty: ");
                    String specialty = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phoneNumber = scanner.nextLine();
                    admin.addTrainer(trainerId, name, email, specialty, phoneNumber);
                }
                case 2 -> {
                    System.out.print("Enter Trainer ID to delete: ");
                    String trainerId = scanner.nextLine();
                    admin.removeTrainer(trainerId);
                }
                case 3 -> {
                    System.out.print("Enter Member ID: ");
                    String memberId = scanner.nextLine();
                    System.out.print("Enter Name: ");
                    String memberName = scanner.nextLine();
                    System.out.print("Enter Membership Type: ");
                    String membershipType = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String memberEmail = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String memberPhoneNumber = scanner.nextLine();
                    System.out.print("Enter Status: ");
                    String status = scanner.nextLine();
                    trainer.addMember(memberId, memberName, membershipType, memberEmail, memberPhoneNumber, status);
                }
                case 4 -> {
                    System.out.print("Enter Class ID: ");
                    String classId = scanner.nextLine();
                    System.out.print("Enter Class Name: ");
                    String className = scanner.nextLine();
                    System.out.print("Enter Trainer ID: ");
                    String classTrainerId = scanner.nextLine();
                    System.out.print("Enter Duration (minutes): ");
                    int duration = scanner.nextInt();
                    System.out.print("Enter Max Participants: ");
                    int maxParticipants = scanner.nextInt();
                    scanner.nextLine();
                    trainer.addClass(classId, className, classTrainerId, duration, maxParticipants);
                }
                case 5 -> {
                    System.out.print("Enter Member ID: ");
                    String regMemberId = scanner.nextLine();
                    System.out.print("Enter Class ID: ");
                    String regClassId = scanner.nextLine();
                    trainer.registerMemberForClass(regMemberId, regClassId, LocalDate.now());
                }
                case 6 -> {
                    System.out.print("Enter Member ID: ");
                    String cancelMemberId = scanner.nextLine();
                    System.out.print("Enter Class ID: ");
                    String cancelClassId = scanner.nextLine();
                    trainer.cancelRegistration(cancelMemberId, cancelClassId);
                }
                case 7 -> {
                    Trainer[] trainers = admin.getListOfTrainers();
                    for (Trainer trainer1 : trainers) {
                        String temp = trainer1.lineRepresentation();
                        String[] temp1 = temp.split(",");
                        System.out.println("Trainer ID: " + temp1[0]);
                        System.out.println("Trainer name: " + temp1[1]);
                        System.out.println("E-mail: " + temp1[2]);
                        System.out.println("Specialty: " + temp1[3]);
                        System.out.println("PhoneNumber: " + temp1[4]);
                    }
                }
                case 8 -> {
                    ArrayList<Member> members = trainer.getListOfMembers();
                    for (Member member : members) {
                        String temp = member.lineRepresentation();
                        String[] temp1 = temp.split(",");
                        System.out.println("Member ID: " + temp1[0]);
                        System.out.println("Member name: " + temp1[1]);
                        System.out.println("Membership type: " + temp1[2]);
                        System.out.println("E-mail: " + temp1[3]);
                        System.out.println("Phone number: " + temp1[4]);
                        System.out.println("Status: " + temp1[5]);
                    }
                }
                case 9 -> {
                    ArrayList<Class> Classes = trainer.getListOfClasses();
                    for (int i = 0; i < Classes.size(); i++) {
                        String temp = Classes.get(i).lineRepresentation();
                        String[] temp1 = temp.split(",");
                        System.out.println("Class ID: " + temp1[0]);
                        System.out.println("Class name: " + temp1[1]);
                        System.out.println("Trainer ID: " + temp1[2]);
                        System.out.println("Class duration: " + temp1[3]);
                        System.out.println("Available seats: " + temp1[4]);
                    }
                }
                case 10 -> {
                    ArrayList<MemberClassRegistration> registrations = trainer.getListOfRegistrations();
                    for (MemberClassRegistration registration : registrations) {
                        String temp = registration.lineRepresentation();
                        String[] temp1 = temp.split(",");
                        System.out.println("Member ID: " + temp1[0]);
                        System.out.println("Class ID: " + temp1[1]);
                        System.out.println("Registration Date: " + temp1[2]);
                        System.out.println("Status: " + temp1[3]);
                    }
                }
                case 11 -> {
                    admin.logout();
                    trainer.logout();
                }
                case 0 ->
                    System.exit(0);
                default ->
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }*/
}
