package backend;

public class MemberDatabase extends Databases {

    public MemberDatabase() {
        super("Members.txt");
    }

    @Override
    public Records createRecordFrom(String line) {
        String[] split = line.split(",\\s*");
        return new Member(split[0], split[1], split[2], split[3], split[4], split[5]);
    }

}
