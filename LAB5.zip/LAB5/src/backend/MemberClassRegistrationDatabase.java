package backend;

import java.time.LocalDate;

public class MemberClassRegistrationDatabase extends Databases {

    public MemberClassRegistrationDatabase() {
        super("Registration.txt");
    }

    @Override
    public Records createRecordFrom(String line) {
        String[] split = line.split(",\\s*");
        return new MemberClassRegistration(split[0], split[1], LocalDate.parse(split[2]), split[3]);
    }
}
