package backend;

import java.time.LocalDate;
import java.util.ArrayList;

public class TrainerRole {

    private MemberDatabase memberDatabase;
    private ClassDatabase classDatabase;
    private MemberClassRegistrationDatabase registrationDatabase;

    public TrainerRole() {
        memberDatabase = new MemberDatabase();
        classDatabase = new ClassDatabase();
        registrationDatabase = new MemberClassRegistrationDatabase();
        memberDatabase.readFromFile();
        classDatabase.readFromFile();
        registrationDatabase.readFromFile();
    }
    public boolean containsMember(String id) {
        if (memberDatabase.contains(id)) {
            return true;
        }
        return false;
    }
    public boolean containsClass(String id) {
        if (classDatabase.contains(id)) {
            return true;
        }
        return false;
    }
    public boolean containsReg(String id) {
        if (registrationDatabase.contains(id)) {
            return true;
        }
        return false;
    }
    public void addMember(String memberID, String name, String membershipType, String email, String phoneNumber, String status) {
        if (memberDatabase.contains(memberID)) {
            System.err.println("Member already exists.");
            return;
        }
        Member newMember = new Member(memberID, name, membershipType, email, phoneNumber, status);
        memberDatabase.insertRecord(newMember);
    }

    public ArrayList<Member> getListOfMembers() {
        ArrayList<Records> allrecords = memberDatabase.returnAllRecords();
        ArrayList<Member> memberlist = new ArrayList<>();
        for (int i = 0; i < allrecords.size(); i++) {
            memberlist.add((Member) allrecords.get(i));
        }
        return memberlist;
    }

    public void addClass(String classID, String className, String trainerID, int duration, int maxParticipants) {
        Class newClass = new Class(classID, className, trainerID, duration, maxParticipants);
        classDatabase.insertRecord(newClass);
    }

    public ArrayList<Class> getListOfClasses() {
        ArrayList<Records> allrecords = classDatabase.returnAllRecords();
        ArrayList<Class> classlist = new ArrayList<>();
        for (int i = 0; i < allrecords.size(); i++) {
            classlist.add((Class) allrecords.get(i));
        }
        return classlist;
    }

    public boolean registerMemberForClass(String memberID, String classID, LocalDate registrationDate) {
        if (classDatabase.contains(classID)) {
            if (((Class) classDatabase.getRecord(classID)).getAvailableSeats() > 0) {
                registrationDatabase.insertRecord(new MemberClassRegistration(memberID, classID, registrationDate, "active"));
                ((Class) classDatabase.getRecord(classID)).setAvailableSeats(((Class) classDatabase.getRecord(classID)).getAvailableSeats() - 1);
                return true;
            } else {
                System.err.println("No available seats in class.");
                return false;
            }
        } else {
            System.err.println("Class doesn't exist.");
            return false;
        }
    }

    public boolean cancelRegistration(String memberID, String classID) {
        if (registrationDatabase.getRecord(memberID + classID) == null) {
            return false;
        }
        if (((MemberClassRegistration) registrationDatabase.getRecord(memberID + classID)).getRegistrationDate().plusDays(3).isAfter(LocalDate.now())) {
            System.out.println("Refund available!");
            ((MemberClassRegistration) registrationDatabase.getRecord(memberID + classID)).setStatus("canceled");
            ((Class) classDatabase.getRecord(classID)).setAvailableSeats(((Class) classDatabase.getRecord(classID)).getAvailableSeats() + 1);
            System.out.println("Class registeration canceled!");
            return true;
        } else {
            System.out.println("More than 3 days have passed since registeration. Can't refund nor cancel.");
            return false;
        }

    }

    public ArrayList<MemberClassRegistration> getListOfRegistrations() {
        ArrayList<Records> allrecords = registrationDatabase.returnAllRecords();
        ArrayList<MemberClassRegistration> mcr = new ArrayList<>();
        for (int i = 0; i < allrecords.size(); i++) {
            mcr.add((MemberClassRegistration) allrecords.get(i));
        }
        return mcr;
    }

    public void logout() {
        classDatabase.saveToFile();
        memberDatabase.saveToFile();
        registrationDatabase.saveToFile();
        System.out.println("Data saved. Log out successful!");
    }
}
