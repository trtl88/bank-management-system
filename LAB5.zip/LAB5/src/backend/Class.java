package backend;

public class Class extends Records {

    private String classID;
    private String className;
    private String trainerID;
    private int duration;
    private int availableSeats;

    public Class(String classID, String className, String trainerID, int duration, int availableSeats) {
        this.classID = classID;
        this.className = className;
        this.trainerID = trainerID;
        this.duration = duration;
        this.availableSeats = availableSeats;
    }
    
    public String getClassID() {
        return classID;
    }

    public String getClassName() {
        return className;
    }

    public String getTrainerID() {
        return trainerID;
    }

    public int getDuration() {
        return duration;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    @Override
    public String lineRepresentation() {
        String info = classID + "," + className + "," + trainerID + "," + duration + "," + availableSeats;
        return info;
    }
    
    @Override
    public String getSearchKey(){
        return classID;
    }
}
