package backend;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class Databases {

    private String filename;
    private ArrayList<Records> r = new ArrayList<>();

    public Databases(String filename) {
        this.filename = filename;
    }

    public void readFromFile() {
        try {
            File f = new File(filename);
            Scanner s = new Scanner(f);
            while (s.hasNextLine()) {
                String line = s.nextLine();
                r.add(createRecordFrom(line));
            }
            s.close();
        } catch (FileNotFoundException ex) {
            System.err.println("ERROR OPENING FILE");
        }
    }

    public abstract Records createRecordFrom(String line);

    public ArrayList<Records> returnAllRecords() {
        return r;
    }

    public boolean contains(String key) {
        for (int i = 0; i < r.size(); i++) {
            if (r.get(i).getSearchKey().equals(key)) {
                return true;
            }
        }
        return false;
    }

    public Records getRecord(String key) {
        for (int i = 0; i < r.size(); i++) {
            if (r.get(i).getSearchKey().equals(key)) {
                return r.get(i);
            }
        }
        return null;
    }

    public void insertRecord(Records record) {
        for (int i = 0; i < r.size(); i++) {
            if (r.get(i).getSearchKey().equals(record.getSearchKey())) {
                System.err.println("Already exists.");
                return;
            }
        }
        r.add(record);
        System.out.println("Added successfully!");
    }

    public void deleteRecord(String key) {
        for (int i = 0; i < r.size(); i++) {
            if (r.get(i).getSearchKey().equals(key)) {
                r.remove(i);
                System.out.println("Deleted!");
                return;
            }
        }
        System.err.println("Not found.");
    }

    public void saveToFile() {
        try {
            FileWriter f = new FileWriter(filename);
            for (int i = 0; i < r.size(); i++) {
                f.write(r.get(i).lineRepresentation());
                f.write(System.lineSeparator());
            }
            f.close();
            System.out.println("Data saved successfully!");
        } catch (IOException ex) {
            System.err.println("Error in file handling.");
        }

    }
}
