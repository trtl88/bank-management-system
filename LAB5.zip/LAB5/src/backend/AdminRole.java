package backend;

import frontend.Addtrainer;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AdminRole {

    private TrainerDatabase database;

    public AdminRole() {
        database = new TrainerDatabase();
        database.readFromFile();
    }

    public boolean contains(String id) {
        if (database.contains(id)) {
            return true;
        }
        return false;
    }

    public void addTrainer(String trainerId, String name, String email, String specialty, String phoneNumber) {
        if (database.contains(trainerId)) {
            return;
        }
        Trainer newTrainer = new Trainer(trainerId, name, email, specialty, phoneNumber);
        database.insertRecord(newTrainer);
    }

    public ArrayList<Trainer> getListOfTrainers() {
        ArrayList<Records> allrecords = database.returnAllRecords();
        ArrayList<Trainer> trainerlist = new ArrayList<>();
        for (int i = 0; i < allrecords.size(); i++) {
            trainerlist.add((Trainer) allrecords.get(i));
        }
        return trainerlist;
    }

    public void removeTrainer(String key) {
        database.deleteRecord(key);
    }

    public void logout() {
        database.saveToFile();
        System.out.println("Log out successful!");
    }
}
