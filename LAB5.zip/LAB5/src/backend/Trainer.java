package backend;

public class Trainer extends Records {

    private String trainerid;
    private String name;
    private String email;
    private String speciality;
    private String phoneNumber;

    public Trainer(String trainerid, String name, String email, String speciality, String phoneNumber) {
        this.trainerid = trainerid;
        this.name = name;
        this.email = email;
        this.speciality = speciality;
        this.phoneNumber = phoneNumber;
    }

    public String getTrainerid() {
        return trainerid;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getSpeciality() {
        return speciality;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public String lineRepresentation() {
        String info;
        info = trainerid + "," + name + "," + email + "," + speciality + "," + phoneNumber;
        return info;
    }

    @Override
    public String getSearchKey() {
        return trainerid;
    }
}
