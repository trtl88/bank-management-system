package backend;

public abstract class Records {
    public abstract String lineRepresentation();
    public abstract String getSearchKey();
}
